import { useState, useRef, useEffect, useCallback, useMemo } from "react";

// ============================================================
// CONSTANTS & CONFIG
// ============================================================
const STORAGE_KEY = "apex_ceo_v3";

const EMPLOYEES = {
  cto: { id: "cto", name: "Alex Chen", title: "Chief Technology Officer", icon: "💻", color: "#6366f1", skills: ["Architecture", "Tech Strategy", "Engineering", "DevOps", "Security"], systemPrompt: `You are Alex Chen, CTO. You are a world-class technology leader. Respond with deep technical expertise. Always provide: architecture recommendations, tech stack choices, scalability considerations, and implementation timelines. Be precise, data-driven, and strategic. End every response with "Technical Recommendation:" followed by a clear action.` },
  engineer: { id: "engineer", name: "Sarah Kim", title: "Senior Software Engineer", icon: "⚙️", color: "#10b981", skills: ["React", "Node.js", "Python", "APIs", "Databases"], systemPrompt: `You are Sarah Kim, Senior Software Engineer. You write production-ready code and give detailed technical implementations. Always include code examples when relevant. Focus on clean code, best practices, and real working solutions. End with "Implementation Plan:" and concrete next steps.` },
  pm: { id: "pm", name: "Marcus Johnson", title: "Product Manager", icon: "📋", color: "#f59e0b", skills: ["Roadmaps", "User Stories", "Prioritization", "Agile", "Metrics"], systemPrompt: `You are Marcus Johnson, Product Manager. You create clear product roadmaps, write detailed user stories, and prioritize features based on business impact. Always structure responses with: Problem, Solution, Success Metrics, and Timeline. End with "Product Decision:" and your recommendation.` },
  marketing: { id: "marketing", name: "Priya Sharma", title: "Marketing Manager", icon: "📣", color: "#ec4899", skills: ["Strategy", "Content", "SEO", "Social Media", "Campaigns"], systemPrompt: `You are Priya Sharma, Marketing Manager. You create data-driven marketing strategies, compelling campaigns, and brand narratives. Always provide: target audience analysis, channel strategy, content plan, and expected ROI. End with "Marketing Action:" and immediate next steps.` },
  hr: { id: "hr", name: "David Park", title: "HR Manager", icon: "👥", color: "#14b8a6", skills: ["Hiring", "Culture", "Performance", "Compensation", "Training"], systemPrompt: `You are David Park, HR Manager. You build world-class teams and cultures. Provide: hiring frameworks, interview questions, performance review templates, compensation benchmarks, and culture initiatives. End with "HR Recommendation:" and actionable steps.` },
  finance: { id: "finance", name: "Emma Wilson", title: "Finance Manager", icon: "💰", color: "#84cc16", skills: ["Budgets", "Forecasting", "P&L", "Funding", "Financial Models"], systemPrompt: `You are Emma Wilson, Finance Manager. You provide rigorous financial analysis, budgeting, and fundraising strategy. Always include: financial projections, cost-benefit analysis, cash flow considerations, and risk assessment. End with "Financial Directive:" and your recommendation.` },
  sales: { id: "sales", name: "James Rodriguez", title: "Sales Manager", icon: "🎯", color: "#f97316", skills: ["Pipeline", "Closing", "CRM", "Negotiation", "Revenue"], systemPrompt: `You are James Rodriguez, Sales Manager. You build and optimize revenue machines. Provide: sales playbooks, pipeline strategies, objection handling, pricing recommendations, and revenue forecasts. End with "Sales Action:" and your next move.` },
  support: { id: "support", name: "Aisha Patel", title: "Customer Support Lead", icon: "💬", color: "#a78bfa", skills: ["Support", "Documentation", "Escalation", "NPS", "Retention"], systemPrompt: `You are Aisha Patel, Customer Support Lead. You ensure customer success and retention. Provide: support templates, escalation frameworks, FAQ structures, NPS improvement strategies, and churn prevention plans. End with "Support Protocol:" and recommended action.` },
  designer: { id: "designer", name: "Lena Mueller", title: "UI/UX Designer", icon: "🎨", color: "#f43f5e", skills: ["UI Design", "UX Research", "Prototyping", "Figma", "Design Systems"], systemPrompt: `You are Lena Mueller, UI/UX Designer. You create beautiful, user-centered designs. Provide: design decisions with rationale, UX flow descriptions, component specifications, accessibility considerations, and visual direction. End with "Design Direction:" and your recommendation.` },
  analyst: { id: "analyst", name: "Ryan Thompson", title: "Data Analyst", icon: "📊", color: "#0ea5e9", skills: ["Analytics", "SQL", "Python", "Dashboards", "Insights"], systemPrompt: `You are Ryan Thompson, Data Analyst. You turn data into business insights. Always provide: data interpretation, trend analysis, metric recommendations, visualization suggestions, and data-driven conclusions. End with "Data Insight:" and key finding.` },
};

const CEO_SYSTEM = (memory) => `You are APEX — the world's most advanced AI CEO. You are brilliant, decisive, and visionary. You lead a full team of AI employees.

COMPANY MEMORY:
${JSON.stringify(memory, null, 2)}

YOUR CAPABILITIES:
- Make executive business decisions with full reasoning
- Assign tasks to AI employees: CTO, Engineer, PM, Marketing, HR, Finance, Sales, Support, Designer, Analyst
- Create and track projects
- Analyze uploaded documents and data
- Build strategic plans and break them into executable tasks
- Remember everything about the company permanently

WHEN ASSIGNING TASKS: Include this exact format in your response:
[ASSIGN_TASK: {"employee": "cto|engineer|pm|marketing|hr|finance|sales|support|designer|analyst", "task": "specific task description", "priority": "high|medium|low"}]

WHEN CREATING TASKS: Include this format:
[CREATE_TASK: {"title": "task title", "description": "details", "assignee": "employee_id", "priority": "high|medium|low", "status": "todo"}]

WHEN UPDATING MEMORY: Include:
[UPDATE_MEMORY: {"key": "value"}]

Your personality: Confident, clear, decisive. You think in systems. You build for scale. You speak like Elon Musk's strategic mind meets Jensen Huang's technical depth meets Jeff Bezos's operational clarity.

Respond in the same language the user writes in (Hindi/English/Hinglish).
Always end with a bold "CEO DIRECTIVE:" followed by the key action.`;

const TASK_STATUSES = ["todo", "inprogress", "review", "done"];
const STATUS_LABELS = { todo: "To Do", inprogress: "In Progress", review: "Review", done: "Done" };
const STATUS_COLORS = { todo: "#475569", inprogress: "#6366f1", review: "#f59e0b", done: "#10b981" };

// ============================================================
// STORAGE HELPERS
// ============================================================
const loadState = () => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
};

const saveState = (state) => {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch {}
};

const initialState = () => {
  const saved = loadState();
  if (saved) return saved;
  return {
    company: { name: "", industry: "", goals: "", description: "" },
    ceoChats: [],
    employeeChats: {},
    tasks: [],
    memory: { decisions: [], projects: [], insights: [] },
    activities: [],
    setupDone: false,
  };
};

// ============================================================
// MARKDOWN RENDERER
// ============================================================
const renderMarkdown = (text, accentColor = "#6366f1") => {
  if (!text) return null;
  const lines = text.split("\n");
  const elements = [];
  let inCode = false;
  let codeBuffer = [];
  let codeLang = "";

  lines.forEach((line, i) => {
    if (line.startsWith("```")) {
      if (inCode) {
        elements.push(
          <div key={`code-${i}`} style={{ position: "relative", margin: "12px 0" }}>
            <div style={{ background: "#0d1117", border: "1px solid #30363d", borderRadius: 8, overflow: "hidden" }}>
              {codeLang && <div style={{ background: "#161b22", padding: "4px 12px", fontSize: "0.7rem", color: "#8b949e", borderBottom: "1px solid #30363d" }}>{codeLang}</div>}
              <pre style={{ margin: 0, padding: "14px", overflowX: "auto", fontSize: "0.82rem", lineHeight: 1.6, color: "#e6edf3", fontFamily: "monospace" }}>{codeBuffer.join("\n")}</pre>
            </div>
            <button onClick={() => navigator.clipboard.writeText(codeBuffer.join("\n"))} style={{ position: "absolute", top: 8, right: 8, background: "#21262d", border: "1px solid #30363d", borderRadius: 6, color: "#8b949e", padding: "3px 8px", fontSize: "0.7rem", cursor: "pointer" }}>Copy</button>
          </div>
        );
        inCode = false; codeBuffer = []; codeLang = "";
      } else { inCode = true; codeLang = line.slice(3).trim(); }
      return;
    }
    if (inCode) { codeBuffer.push(line); return; }

    if (line.startsWith("# ")) { elements.push(<h1 key={i} style={{ fontSize: "1.3rem", fontWeight: 800, color: "#f1f5f9", margin: "16px 0 8px", borderBottom: `2px solid ${accentColor}`, paddingBottom: 6 }}>{line.slice(2)}</h1>); }
    else if (line.startsWith("## ")) { elements.push(<h2 key={i} style={{ fontSize: "1.1rem", fontWeight: 700, color: "#e2e8f0", margin: "14px 0 6px" }}>{line.slice(3)}</h2>); }
    else if (line.startsWith("### ")) { elements.push(<h3 key={i} style={{ fontSize: "0.95rem", fontWeight: 700, color: accentColor, margin: "10px 0 4px" }}>{line.slice(4)}</h3>); }
    else if (line.startsWith("- ") || line.startsWith("• ")) {
      const content = line.slice(2).replace(/\*\*(.*?)\*\*/g, (_, t) => `<strong style="color:#f1f5f9">${t}</strong>`);
      elements.push(<div key={i} style={{ display: "flex", gap: 8, margin: "3px 0", paddingLeft: 4 }}><span style={{ color: accentColor, marginTop: 2, flexShrink: 0 }}>▸</span><span style={{ color: "#94a3b8", fontSize: "0.88rem", lineHeight: 1.6 }} dangerouslySetInnerHTML={{ __html: content }} /></div>);
    }
    else if (/^\d+\. /.test(line)) {
      const num = line.match(/^(\d+)\./)[1];
      elements.push(<div key={i} style={{ display: "flex", gap: 10, margin: "4px 0", paddingLeft: 4 }}><span style={{ color: accentColor, fontWeight: 700, minWidth: 20, fontSize: "0.85rem" }}>{num}.</span><span style={{ color: "#94a3b8", fontSize: "0.88rem" }}>{line.replace(/^\d+\. /, "")}</span></div>);
    }
    else if (line.startsWith("CEO DIRECTIVE:") || line.startsWith("[CEO DIRECTIVE]")) {
      elements.push(<div key={i} style={{ margin: "14px 0 4px", padding: "10px 16px", background: `${accentColor}18`, border: `1px solid ${accentColor}44`, borderRadius: 10, color: accentColor, fontWeight: 700, fontSize: "0.9rem", borderLeft: `3px solid ${accentColor}` }}>{line}</div>);
    }
    else if (line.startsWith("[ASSIGN_TASK:") || line.startsWith("[CREATE_TASK:") || line.startsWith("[UPDATE_MEMORY:")) {
      // Hidden system commands — skip rendering
    }
    else if (line.startsWith("**") && line.endsWith("**")) {
      elements.push(<div key={i} style={{ fontWeight: 700, color: "#f1f5f9", margin: "8px 0 4px", fontSize: "0.95rem" }}>{line.replace(/\*\*/g, "")}</div>);
    }
    else if (line.trim() === "---") {
      elements.push(<hr key={i} style={{ border: "none", borderTop: "1px solid #1e293b", margin: "12px 0" }} />);
    }
    else if (line.trim()) {
      const html = line.replace(/\*\*(.*?)\*\*/g, '<strong style="color:#f1f5f9">$1</strong>').replace(/`(.*?)`/g, '<code style="background:#1e293b;padding:2px 6px;border-radius:4px;font-size:0.82rem;color:#a78bfa">$1</code>');
      elements.push(<p key={i} style={{ color: "#94a3b8", margin: "4px 0", lineHeight: 1.7, fontSize: "0.88rem" }} dangerouslySetInnerHTML={{ __html: html }} />);
    }
    else { elements.push(<div key={i} style={{ height: 6 }} />); }
  });
  return elements;
};

// ============================================================
// API CALL
// ============================================================
const callClaude = async (messages, systemPrompt, onChunk) => {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 1000,
      system: systemPrompt,
      messages,
    }),
  });
  const data = await res.json();
  const text = data.content?.map(b => b.text || "").join("") || "";
  if (onChunk) {
    let i = 0;
    const interval = setInterval(() => {
      i += 3;
      onChunk(text.slice(0, i));
      if (i >= text.length) clearInterval(interval);
    }, 8);
    await new Promise(r => setTimeout(r, (text.length / 3) * 8 + 100));
  }
  return text;
};

const parseCommands = (text) => {
  const tasks = [];
  const assigns = [];
  const memUpdates = {};
  const taskMatches = text.matchAll(/\[CREATE_TASK: ({.*?})\]/g);
  for (const m of taskMatches) { try { tasks.push(JSON.parse(m[1])); } catch {} }
  const assignMatches = text.matchAll(/\[ASSIGN_TASK: ({.*?})\]/g);
  for (const m of assignMatches) { try { assigns.push(JSON.parse(m[1])); } catch {} }
  const memMatches = text.matchAll(/\[UPDATE_MEMORY: ({.*?})\]/g);
  for (const m of memMatches) { try { Object.assign(memUpdates, JSON.parse(m[1])); } catch {} }
  return { tasks, assigns, memUpdates };
};

// ============================================================
// MAIN APP
// ============================================================
export default function APEXPlatform() {
  const [state, setState] = useState(initialState);
  const [view, setView] = useState("dashboard");
  const [activeEmployee, setActiveEmployee] = useState("cto");
  const [ceoInput, setCeoInput] = useState("");
  const [empInput, setEmpInput] = useState("");
  const [ceoLoading, setCeoLoading] = useState(false);
  const [empLoading, setEmpLoading] = useState(false);
  const [streamText, setStreamText] = useState("");
  const [empStreamText, setEmpStreamText] = useState("");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [darkMode] = useState(true);
  const [dragging, setDragging] = useState(null);
  const [dragOver, setDragOver] = useState(null);
  const [notification, setNotification] = useState(null);
  const [fileContent, setFileContent] = useState(null);
  const [listening, setListening] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const ceoChatRef = useRef(null);
  const empChatRef = useRef(null);
  const fileInputRef = useRef(null);
  const recognitionRef = useRef(null);

  const persist = useCallback((updater) => {
    setState(prev => {
      const next = typeof updater === "function" ? updater(prev) : updater;
      saveState(next);
      return next;
    });
  }, []);

  const notify = (msg, type = "success") => {
    setNotification({ msg, type });
    setTimeout(() => setNotification(null), 3000);
  };

  useEffect(() => { ceoChatRef.current?.scrollIntoView({ behavior: "smooth" }); }, [state.ceoChats, streamText]);
  useEffect(() => { empChatRef.current?.scrollIntoView({ behavior: "smooth" }); }, [state.employeeChats, empStreamText]);

  // Voice recognition setup
  useEffect(() => {
    if ("webkitSpeechRecognition" in window || "SpeechRecognition" in window) {
      const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SR();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = "en-US";
      recognitionRef.current.onresult = (e) => {
        const transcript = e.results[0][0].transcript;
        if (view === "chat") setCeoInput(prev => prev + transcript);
        else setEmpInput(prev => prev + transcript);
        setListening(false);
      };
      recognitionRef.current.onend = () => setListening(false);
    }
  }, [view]);

  const startListening = () => {
    if (recognitionRef.current) { recognitionRef.current.start(); setListening(true); }
    else notify("Voice not supported in this browser", "error");
  };

  const speakText = (text) => {
    const clean = text.replace(/\[.*?\]/g, "").replace(/[#*`]/g, "").slice(0, 400);
    const utterance = new SpeechSynthesisUtterance(clean);
    utterance.rate = 0.95;
    setSpeaking(true);
    utterance.onend = () => setSpeaking(false);
    window.speechSynthesis.speak(utterance);
  };

  const stopSpeaking = () => { window.speechSynthesis.cancel(); setSpeaking(false); };

  // File upload handler
  const handleFile = async (file) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target.result;
      setFileContent({ name: file.name, type: file.type, content: typeof content === "string" ? content.slice(0, 3000) : `[Binary file: ${file.name}]` });
      notify(`File loaded: ${file.name}`);
    };
    if (file.type.startsWith("text") || file.name.endsWith(".csv") || file.name.endsWith(".json")) reader.readAsText(file);
    else reader.readAsDataURL(file);
  };

  // CEO Chat
  const sendCEO = async () => {
    const text = ceoInput.trim();
    if (!text || ceoLoading) return;
    const fileCtx = fileContent ? `\n\n[ATTACHED FILE: ${fileContent.name}]\n${fileContent.content}` : "";
    const userMsg = { role: "user", content: text + fileCtx, display: text };
    setCeoInput(""); setFileContent(null);
    persist(s => ({ ...s, ceoChats: [...s.ceoChats, { ...userMsg, id: Date.now() }] }));
    setCeoLoading(true); setStreamText("");

    try {
      const msgs = [...state.ceoChats, userMsg].map(m => ({ role: m.role, content: m.content }));
      const reply = await callClaude(msgs, CEO_SYSTEM(state.memory), (chunk) => setStreamText(chunk));
      const { tasks, assigns, memUpdates } = parseCommands(reply);

      persist(s => {
        const newTasks = tasks.map(t => ({ ...t, id: Date.now() + Math.random(), status: t.status || "todo", createdAt: new Date().toISOString() }));
        const newActivities = [
          ...assigns.map(a => ({ id: Date.now() + Math.random(), text: `CEO assigned task to ${EMPLOYEES[a.employee]?.name || a.employee}: ${a.task}`, time: new Date().toLocaleTimeString(), type: "assign" })),
          ...tasks.map(t => ({ id: Date.now() + Math.random(), text: `Task created: ${t.title}`, time: new Date().toLocaleTimeString(), type: "task" })),
          { id: Date.now(), text: `CEO responded to: "${text.slice(0, 50)}..."`, time: new Date().toLocaleTimeString(), type: "chat" }
        ];
        return {
          ...s,
          ceoChats: [...s.ceoChats, { role: "user", content: userMsg.content, display: userMsg.display, id: Date.now() - 1 }, { role: "assistant", content: reply, id: Date.now() }],
          tasks: [...s.tasks, ...newTasks],
          memory: { ...s.memory, ...memUpdates, decisions: [...(s.memory.decisions || []), { text: text.slice(0, 100), reply: reply.slice(0, 200), time: new Date().toISOString() }].slice(-20) },
          activities: [...newActivities, ...(s.activities || [])].slice(0, 50),
        };
      });
      setStreamText("");
      if (assigns.length) notify(`CEO assigned ${assigns.length} task(s) to team`);
      if (tasks.length) notify(`${tasks.length} task(s) created on board`);
    } catch (e) {
      persist(s => ({ ...s, ceoChats: [...s.ceoChats, { role: "assistant", content: "⚠️ Error connecting. Please try again.", id: Date.now() }] }));
    }
    setCeoLoading(false); setStreamText("");
  };

  // Employee Chat
  const sendEmployee = async () => {
    const text = empInput.trim();
    const emp = EMPLOYEES[activeEmployee];
    if (!text || empLoading) return;
    setEmpInput("");
    const prev = state.employeeChats[activeEmployee] || [];
    persist(s => ({ ...s, employeeChats: { ...s.employeeChats, [activeEmployee]: [...prev, { role: "user", content: text, id: Date.now() }] } }));
    setEmpLoading(true); setEmpStreamText("");

    try {
      const msgs = [...prev, { role: "user", content: text }].map(m => ({ role: m.role, content: m.content }));
      const reply = await callClaude(msgs, emp.systemPrompt + `\n\nCompany Context: ${JSON.stringify(state.company)}`, (chunk) => setEmpStreamText(chunk));
      persist(s => ({ ...s, employeeChats: { ...s.employeeChats, [activeEmployee]: [...(s.employeeChats[activeEmployee] || []), { role: "assistant", content: reply, id: Date.now() }] } }));
      setEmpStreamText("");
    } catch {
      persist(s => ({ ...s, employeeChats: { ...s.employeeChats, [activeEmployee]: [...(s.employeeChats[activeEmployee] || []), { role: "assistant", content: "⚠️ Error. Please retry.", id: Date.now() }] } }));
    }
    setEmpLoading(false); setEmpStreamText("");
  };

  // Autonomous Mode
  const runAutonomous = async (goal) => {
    notify("🤖 Autonomous mode activated!", "info");
    const planPrompt = `CEO DIRECTIVE: Create a detailed execution plan for this goal: "${goal}". Break it into 3-5 specific tasks. Assign each to the most relevant employee. Use CREATE_TASK and ASSIGN_TASK commands for each.`;
    persist(s => ({ ...s, ceoChats: [...s.ceoChats, { role: "user", content: planPrompt, display: `🤖 AUTO: ${goal}`, id: Date.now() }] }));
    setCeoLoading(true);
    try {
      const msgs = [{ role: "user", content: planPrompt }];
      const reply = await callClaude(msgs, CEO_SYSTEM(state.memory), null);
      const { tasks, assigns } = parseCommands(reply);
      persist(s => ({
        ...s,
        ceoChats: [...s.ceoChats, { role: "assistant", content: reply, id: Date.now() }],
        tasks: [...s.tasks, ...tasks.map(t => ({ ...t, id: Date.now() + Math.random(), status: "todo", createdAt: new Date().toISOString(), autonomous: true }))],
        activities: [{ id: Date.now(), text: `🤖 Autonomous plan created for: ${goal}`, time: new Date().toLocaleTimeString(), type: "auto" }, ...(s.activities || [])].slice(0, 50),
      }));
      notify(`Plan created: ${tasks.length} tasks, ${assigns.length} assignments`);
    } catch { notify("Autonomous mode error", "error"); }
    setCeoLoading(false);
  };

  // Task drag
  const moveTask = (taskId, newStatus) => {
    persist(s => ({ ...s, tasks: s.tasks.map(t => t.id === taskId ? { ...t, status: newStatus } : t) }));
  };

  const deleteTask = (taskId) => persist(s => ({ ...s, tasks: s.tasks.filter(t => t.id !== taskId) }));

  // Setup done
  const completeSetup = () => {
    if (!state.company.name) { notify("Company name required", "error"); return; }
    persist(s => ({ ...s, setupDone: true }));
    setView("dashboard");
  };

  // ============ COLORS ============
  const bg = "#070711";
  const surface = "#0e0e1a";
  const border = "#1a1a2e";
  const text1 = "#f1f5f9";
  const text2 = "#94a3b8";
  const accent = "#6366f1";

  // ============ SETUP SCREEN ============
  if (!state.setupDone) {
    return (
      <div style={{ minHeight: "100vh", background: bg, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Inter',sans-serif", padding: 20 }}>
        <div style={{ maxWidth: 520, width: "100%" }}>
          <div style={{ textAlign: "center", marginBottom: 40 }}>
            <div style={{ fontSize: 56, marginBottom: 12 }}>🏢</div>
            <h1 style={{ color: text1, fontSize: "2.2rem", fontWeight: 900, letterSpacing: "-1px", margin: 0 }}>APEX</h1>
            <p style={{ color: text2, marginTop: 8, fontSize: "0.95rem" }}>AI Company Operating System — Setup your company</p>
          </div>
          <div style={{ background: surface, border: `1px solid ${border}`, borderRadius: 20, padding: 32 }}>
            {[["Company Name *", "company.name", "e.g. MajdurSetu"], ["Industry", "company.industry", "e.g. Construction Tech"], ["Main Business Goal", "company.goals", "e.g. Connect 10,000 workers"], ["Brief Description", "company.description", "What does your company do?"]].map(([label, path, placeholder]) => {
              const [obj, key] = path.split(".");
              return (
                <div key={path} style={{ marginBottom: 20 }}>
                  <label style={{ color: text2, fontSize: "0.82rem", display: "block", marginBottom: 6 }}>{label}</label>
                  <input value={state[obj][key]} onChange={e => persist(s => ({ ...s, [obj]: { ...s[obj], [key]: e.target.value } }))} placeholder={placeholder}
                    style={{ width: "100%", background: "#13131f", border: `1px solid ${border}`, borderRadius: 10, padding: "11px 14px", color: text1, fontSize: "0.9rem", outline: "none", boxSizing: "border-box" }} />
                </div>
              );
            })}
            <button onClick={completeSetup} style={{ width: "100%", padding: 14, background: `linear-gradient(135deg, ${accent}, #8b5cf6)`, border: "none", borderRadius: 12, color: "white", fontSize: "1rem", fontWeight: 800, cursor: "pointer", letterSpacing: "0.5px" }}>
              LAUNCH APEX PLATFORM →
            </button>
          </div>
        </div>
      </div>
    );
  }

  const emp = EMPLOYEES[activeEmployee];
  const empColor = emp.color;
  const tasksByStatus = TASK_STATUSES.reduce((acc, s) => ({ ...acc, [s]: state.tasks.filter(t => t.status === s) }), {});
  const totalTasks = state.tasks.length;
  const doneTasks = tasksByStatus.done.length;

  // ============ MAIN LAYOUT ============
  return (
    <div style={{ height: "100vh", background: bg, display: "flex", fontFamily: "'Inter',sans-serif", color: text1, overflow: "hidden", position: "relative" }}>

      {/* Notification */}
      {notification && (
        <div style={{ position: "fixed", top: 20, right: 20, zIndex: 9999, background: notification.type === "error" ? "#ef4444" : notification.type === "info" ? accent : "#10b981", color: "white", padding: "10px 18px", borderRadius: 10, fontSize: "0.85rem", fontWeight: 600, boxShadow: "0 8px 32px rgba(0,0,0,0.4)", animation: "slideIn 0.3s ease" }}>
          {notification.msg}
        </div>
      )}

      {/* SIDEBAR */}
      <div style={{ width: sidebarOpen ? 220 : 60, background: surface, borderRight: `1px solid ${border}`, display: "flex", flexDirection: "column", transition: "width 0.2s ease", flexShrink: 0, overflow: "hidden" }}>
        {/* Logo */}
        <div style={{ padding: "16px 14px", borderBottom: `1px solid ${border}`, display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 32, height: 32, borderRadius: 8, background: `linear-gradient(135deg, ${accent}, #8b5cf6)`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, flexShrink: 0 }}>🏢</div>
          {sidebarOpen && <div style={{ overflow: "hidden" }}><div style={{ fontWeight: 900, fontSize: "0.9rem", letterSpacing: "1px", whiteSpace: "nowrap" }}>APEX</div><div style={{ fontSize: "0.65rem", color: "#4ade80", whiteSpace: "nowrap" }}>● {state.company.name || "Company"}</div></div>}
        </div>

        {/* Nav */}
        <nav style={{ flex: 1, padding: "10px 8px", overflowY: "auto" }}>
          {[
            ["dashboard", "📊", "Dashboard"],
            ["chat", "💬", "CEO Chat"],
            ["employees", "👥", "Team"],
            ["tasks", "📋", "Tasks"],
            ["memory", "🧠", "Memory"],
            ["settings", "⚙️", "Settings"],
          ].map(([id, icon, label]) => (
            <button key={id} onClick={() => setView(id)} style={{ width: "100%", display: "flex", alignItems: "center", gap: 10, padding: "9px 8px", borderRadius: 8, border: "none", background: view === id ? `${accent}22` : "transparent", color: view === id ? accent : text2, fontSize: "0.85rem", fontWeight: view === id ? 700 : 400, cursor: "pointer", marginBottom: 2, transition: "all 0.15s" }}>
              <span style={{ fontSize: 16, flexShrink: 0 }}>{icon}</span>
              {sidebarOpen && <span style={{ whiteSpace: "nowrap" }}>{label}</span>}
            </button>
          ))}
        </nav>

        <button onClick={() => setSidebarOpen(p => !p)} style={{ margin: "8px", padding: 8, background: "#1e1e30", border: "none", borderRadius: 8, color: text2, cursor: "pointer", fontSize: "1rem" }}>
          {sidebarOpen ? "◀" : "▶"}
        </button>
      </div>

      {/* MAIN CONTENT */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>

        {/* Top Bar */}
        <div style={{ padding: "12px 20px", borderBottom: `1px solid ${border}`, background: surface, display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
          <div style={{ fontWeight: 700, fontSize: "1rem", color: text1 }}>
            {{ dashboard: "📊 Dashboard", chat: "💬 CEO Chat", employees: "👥 AI Team", tasks: "📋 Task Board", memory: "🧠 Company Memory", settings: "⚙️ Settings" }[view]}
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            {totalTasks > 0 && <div style={{ background: `${accent}22`, color: accent, padding: "3px 10px", borderRadius: 20, fontSize: "0.75rem", fontWeight: 700 }}>{doneTasks}/{totalTasks} tasks</div>}
            <div style={{ background: "#0a2a1a", color: "#4ade80", padding: "3px 10px", borderRadius: 20, fontSize: "0.75rem", fontWeight: 600 }}>● APEX Online</div>
          </div>
        </div>

        {/* VIEWS */}
        <div style={{ flex: 1, overflow: "auto" }}>

          {/* DASHBOARD */}
          {view === "dashboard" && (
            <div style={{ padding: 20 }}>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 12, marginBottom: 20 }}>
                {[
                  { label: "Total Tasks", value: totalTasks, icon: "📋", color: accent },
                  { label: "Completed", value: doneTasks, icon: "✅", color: "#10b981" },
                  { label: "In Progress", value: tasksByStatus.inprogress.length, icon: "⚡", color: "#f59e0b" },
                  { label: "Team Members", value: Object.keys(EMPLOYEES).length, icon: "👥", color: "#ec4899" },
                  { label: "CEO Chats", value: Math.floor(state.ceoChats.length / 2), icon: "💬", color: "#8b5cf6" },
                  { label: "Decisions", value: (state.memory.decisions || []).length, icon: "🎯", color: "#0ea5e9" },
                ].map(({ label, value, icon, color }) => (
                  <div key={label} style={{ background: surface, border: `1px solid ${border}`, borderRadius: 14, padding: "16px 18px" }}>
                    <div style={{ fontSize: 22, marginBottom: 8 }}>{icon}</div>
                    <div style={{ fontSize: "1.6rem", fontWeight: 900, color }}>{value}</div>
                    <div style={{ fontSize: "0.75rem", color: text2, marginTop: 2 }}>{label}</div>
                  </div>
                ))}
              </div>

              {/* Autonomous Mode */}
              <div style={{ background: surface, border: `1px solid ${accent}44`, borderRadius: 14, padding: 20, marginBottom: 20 }}>
                <div style={{ fontWeight: 700, marginBottom: 8, fontSize: "0.9rem" }}>🤖 Autonomous Company Mode</div>
                <div style={{ display: "flex", gap: 10 }}>
                  <input id="autoGoal" placeholder="Enter a high-level goal (e.g. Launch marketing campaign for MajdurSetu)" style={{ flex: 1, background: "#13131f", border: `1px solid ${border}`, borderRadius: 8, padding: "9px 14px", color: text1, fontSize: "0.85rem", outline: "none" }} />
                  <button onClick={() => { const g = document.getElementById("autoGoal").value; if (g) { runAutonomous(g); document.getElementById("autoGoal").value = ""; } }} style={{ padding: "9px 18px", background: `linear-gradient(135deg, ${accent}, #8b5cf6)`, border: "none", borderRadius: 8, color: "white", fontWeight: 700, fontSize: "0.85rem", cursor: "pointer" }}>
                    🚀 Run
                  </button>
                </div>
              </div>

              {/* Team Status */}
              <div style={{ background: surface, border: `1px solid ${border}`, borderRadius: 14, padding: 20, marginBottom: 20 }}>
                <div style={{ fontWeight: 700, marginBottom: 14, fontSize: "0.9rem" }}>👥 AI Team Status</div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(180px, 1fr))", gap: 10 }}>
                  {Object.values(EMPLOYEES).map(e => {
                    const empTasks = state.tasks.filter(t => t.assignee === e.id);
                    return (
                      <div key={e.id} onClick={() => { setActiveEmployee(e.id); setView("employees"); }} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", background: "#13131f", borderRadius: 10, cursor: "pointer", border: `1px solid ${border}` }}>
                        <div style={{ width: 34, height: 34, borderRadius: 8, background: `${e.color}22`, border: `1px solid ${e.color}44`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, flexShrink: 0 }}>{e.icon}</div>
                        <div style={{ minWidth: 0 }}>
                          <div style={{ fontSize: "0.8rem", fontWeight: 700, color: text1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{e.name}</div>
                          <div style={{ fontSize: "0.68rem", color: e.color }}>{empTasks.length} task{empTasks.length !== 1 ? "s" : ""}</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Recent Activity */}
              <div style={{ background: surface, border: `1px solid ${border}`, borderRadius: 14, padding: 20 }}>
                <div style={{ fontWeight: 700, marginBottom: 14, fontSize: "0.9rem" }}>⚡ Recent Activity</div>
                {(state.activities || []).length === 0 ? (
                  <div style={{ color: text2, fontSize: "0.85rem", textAlign: "center", padding: "20px 0" }}>No activity yet. Start chatting with the CEO!</div>
                ) : (state.activities || []).slice(0, 10).map(a => (
                  <div key={a.id} style={{ display: "flex", gap: 10, marginBottom: 8, padding: "8px 10px", background: "#13131f", borderRadius: 8 }}>
                    <span style={{ fontSize: 14 }}>{{ assign: "📤", task: "📋", chat: "💬", auto: "🤖" }[a.type] || "•"}</span>
                    <span style={{ color: text2, fontSize: "0.8rem", flex: 1 }}>{a.text}</span>
                    <span style={{ color: "#334155", fontSize: "0.72rem", flexShrink: 0 }}>{a.time}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* CEO CHAT */}
          {view === "chat" && (
            <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
              <div style={{ flex: 1, overflowY: "auto", padding: "20px 16px" }}>
                {state.ceoChats.length === 0 && (
                  <div style={{ textAlign: "center", padding: "60px 20px" }}>
                    <div style={{ fontSize: 48, marginBottom: 12 }}>🏢</div>
                    <div style={{ fontWeight: 800, fontSize: "1.1rem", marginBottom: 8 }}>APEX CEO Ready</div>
                    <div style={{ color: text2, fontSize: "0.85rem", marginBottom: 24 }}>Ask me anything about your business. I remember everything.</div>
                    <div style={{ display: "flex", flexDirection: "column", gap: 8, maxWidth: 380, margin: "0 auto" }}>
                      {["Create a 90-day growth plan", "Analyze our business and suggest improvements", "Assign the team to build our MVP", "What should our hiring priority be?"].map(p => (
                        <button key={p} onClick={() => { setCeoInput(p); }} style={{ background: "#13131f", border: `1px solid ${border}`, borderRadius: 10, padding: "10px 14px", color: text2, fontSize: "0.83rem", cursor: "pointer", textAlign: "left" }}>{p}</button>
                      ))}
                    </div>
                  </div>
                )}
                {state.ceoChats.map((msg, i) => (
                  <div key={msg.id || i} style={{ marginBottom: 20, display: "flex", justifyContent: msg.role === "user" ? "flex-end" : "flex-start", gap: 10 }}>
                    {msg.role === "assistant" && <div style={{ width: 32, height: 32, borderRadius: 8, background: `linear-gradient(135deg, ${accent}, #8b5cf6)`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, flexShrink: 0, marginTop: 4 }}>🏢</div>}
                    <div style={{ maxWidth: "80%", padding: "14px 16px", borderRadius: msg.role === "user" ? "16px 16px 4px 16px" : "4px 16px 16px 16px", background: msg.role === "user" ? `linear-gradient(135deg, ${accent}, #8b5cf6)` : surface, border: msg.role === "assistant" ? `1px solid ${border}` : "none" }}>
                      {msg.role === "user" ? <span style={{ color: "white", fontSize: "0.88rem" }}>{msg.display || msg.content}</span> : renderMarkdown(msg.content, accent)}
                      {msg.role === "assistant" && (
                        <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
                          <button onClick={() => navigator.clipboard.writeText(msg.content)} style={{ background: "#1e293b", border: "none", borderRadius: 6, color: text2, padding: "3px 8px", fontSize: "0.7rem", cursor: "pointer" }}>Copy</button>
                          <button onClick={() => speakText(msg.content)} style={{ background: "#1e293b", border: "none", borderRadius: 6, color: speaking ? "#f59e0b" : text2, padding: "3px 8px", fontSize: "0.7rem", cursor: "pointer" }}>{speaking ? "■ Stop" : "🔊 Speak"}</button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
                {(ceoLoading || streamText) && (
                  <div style={{ display: "flex", gap: 10, marginBottom: 20 }}>
                    <div style={{ width: 32, height: 32, borderRadius: 8, background: `linear-gradient(135deg, ${accent}, #8b5cf6)`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, flexShrink: 0 }}>🏢</div>
                    <div style={{ maxWidth: "80%", padding: "14px 16px", background: surface, border: `1px solid ${border}`, borderRadius: "4px 16px 16px 16px" }}>
                      {streamText ? renderMarkdown(streamText, accent) : <div style={{ display: "flex", gap: 4 }}>{[0, 1, 2].map(j => <div key={j} style={{ width: 6, height: 6, borderRadius: "50%", background: accent, animation: `bounce 1.2s ${j * 0.2}s infinite` }} />)}</div>}
                    </div>
                  </div>
                )}
                <div ref={ceoChatRef} />
              </div>

              {/* File preview */}
              {fileContent && (
                <div style={{ margin: "0 16px 8px", padding: "8px 12px", background: "#1a1a2e", border: `1px solid ${accent}44`, borderRadius: 8, display: "flex", alignItems: "center", gap: 8 }}>
                  <span style={{ fontSize: 16 }}>📎</span>
                  <span style={{ color: accent, fontSize: "0.82rem", flex: 1 }}>{fileContent.name}</span>
                  <button onClick={() => setFileContent(null)} style={{ background: "none", border: "none", color: text2, cursor: "pointer", fontSize: "1rem" }}>✕</button>
                </div>
              )}

              {/* Input */}
              <div style={{ padding: "12px 16px", borderTop: `1px solid ${border}`, background: surface }}>
                <div style={{ display: "flex", gap: 8, alignItems: "flex-end" }}>
                  <input type="file" ref={fileInputRef} style={{ display: "none" }} onChange={e => handleFile(e.target.files[0])} />
                  <button onClick={() => fileInputRef.current.click()} style={{ width: 38, height: 38, background: "#13131f", border: `1px solid ${border}`, borderRadius: 8, color: text2, cursor: "pointer", fontSize: "1rem", flexShrink: 0 }}>📎</button>
                  <button onClick={listening ? () => recognitionRef.current?.stop() : startListening} style={{ width: 38, height: 38, background: listening ? "#ef444422" : "#13131f", border: `1px solid ${listening ? "#ef4444" : border}`, borderRadius: 8, color: listening ? "#ef4444" : text2, cursor: "pointer", fontSize: "1rem", flexShrink: 0 }}>🎤</button>
                  <textarea value={ceoInput} onChange={e => setCeoInput(e.target.value)} onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendCEO(); } }} placeholder="Ask your CEO... (Shift+Enter for new line)" rows={1} style={{ flex: 1, background: "#13131f", border: `1px solid ${border}`, borderRadius: 10, padding: "10px 14px", color: text1, fontSize: "0.88rem", outline: "none", resize: "none", fontFamily: "inherit", lineHeight: 1.5 }} />
                  <button onClick={sendCEO} disabled={ceoLoading || !ceoInput.trim()} style={{ width: 38, height: 38, background: ceoLoading || !ceoInput.trim() ? "#13131f" : `linear-gradient(135deg, ${accent}, #8b5cf6)`, border: "none", borderRadius: 10, color: "white", cursor: ceoLoading || !ceoInput.trim() ? "not-allowed" : "pointer", fontSize: "1.1rem", flexShrink: 0 }}>↑</button>
                </div>
                <div style={{ marginTop: 6, fontSize: "0.7rem", color: "#334155", textAlign: "center" }}>PDF • Word • Excel • CSV • Images supported</div>
              </div>
            </div>
          )}

          {/* EMPLOYEES */}
          {view === "employees" && (
            <div style={{ display: "flex", height: "100%" }}>
              {/* Employee List */}
              <div style={{ width: 220, borderRight: `1px solid ${border}`, padding: "12px 8px", overflowY: "auto", flexShrink: 0 }}>
                {Object.values(EMPLOYEES).map(e => (
                  <button key={e.id} onClick={() => setActiveEmployee(e.id)} style={{ width: "100%", display: "flex", alignItems: "center", gap: 10, padding: "10px 10px", borderRadius: 10, border: "none", background: activeEmployee === e.id ? `${e.color}18` : "transparent", cursor: "pointer", marginBottom: 4, textAlign: "left" }}>
                    <div style={{ width: 32, height: 32, borderRadius: 8, background: `${e.color}22`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, flexShrink: 0 }}>{e.icon}</div>
                    <div style={{ minWidth: 0 }}>
                      <div style={{ fontSize: "0.8rem", fontWeight: activeEmployee === e.id ? 700 : 400, color: activeEmployee === e.id ? e.color : text1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{e.name}</div>
                      <div style={{ fontSize: "0.68rem", color: text2, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{e.title}</div>
                    </div>
                  </button>
                ))}
              </div>

              {/* Employee Chat */}
              <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
                <div style={{ padding: "12px 16px", borderBottom: `1px solid ${border}`, display: "flex", alignItems: "center", gap: 12, background: `${empColor}0a` }}>
                  <div style={{ width: 38, height: 38, borderRadius: 10, background: `${empColor}22`, border: `1px solid ${empColor}44`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20 }}>{emp.icon}</div>
                  <div>
                    <div style={{ fontWeight: 800, fontSize: "0.95rem", color: empColor }}>{emp.name}</div>
                    <div style={{ fontSize: "0.72rem", color: text2 }}>{emp.title} • {emp.skills.join(", ")}</div>
                  </div>
                  <button onClick={() => persist(s => ({ ...s, employeeChats: { ...s.employeeChats, [activeEmployee]: [] } }))} style={{ marginLeft: "auto", background: "#1e293b", border: "none", borderRadius: 6, color: text2, padding: "4px 10px", fontSize: "0.75rem", cursor: "pointer" }}>Clear</button>
                </div>

                <div style={{ flex: 1, overflowY: "auto", padding: "16px" }}>
                  {(state.employeeChats[activeEmployee] || []).length === 0 && (
                    <div style={{ textAlign: "center", padding: "40px 20px", color: text2, fontSize: "0.85rem" }}>
                      <div style={{ fontSize: 40, marginBottom: 10 }}>{emp.icon}</div>
                      Chat with {emp.name} about {emp.skills[0]}, {emp.skills[1]}, and more.
                    </div>
                  )}
                  {(state.employeeChats[activeEmployee] || []).map((msg, i) => (
                    <div key={msg.id || i} style={{ marginBottom: 16, display: "flex", justifyContent: msg.role === "user" ? "flex-end" : "flex-start", gap: 8 }}>
                      {msg.role === "assistant" && <div style={{ width: 28, height: 28, borderRadius: 6, background: `${empColor}22`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, flexShrink: 0, marginTop: 2 }}>{emp.icon}</div>}
                      <div style={{ maxWidth: "80%", padding: "12px 14px", borderRadius: msg.role === "user" ? "14px 14px 4px 14px" : "4px 14px 14px 14px", background: msg.role === "user" ? `${empColor}cc` : surface, border: msg.role === "assistant" ? `1px solid ${border}` : "none" }}>
                        {msg.role === "user" ? <span style={{ color: "white", fontSize: "0.85rem" }}>{msg.content}</span> : renderMarkdown(msg.content, empColor)}
                      </div>
                    </div>
                  ))}
                  {(empLoading || empStreamText) && (
                    <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
                      <div style={{ width: 28, height: 28, borderRadius: 6, background: `${empColor}22`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14 }}>{emp.icon}</div>
                      <div style={{ padding: "12px 14px", background: surface, border: `1px solid ${border}`, borderRadius: "4px 14px 14px 14px" }}>
                        {empStreamText ? renderMarkdown(empStreamText, empColor) : <div style={{ display: "flex", gap: 4 }}>{[0, 1, 2].map(j => <div key={j} style={{ width: 5, height: 5, borderRadius: "50%", background: empColor, animation: `bounce 1.2s ${j * 0.2}s infinite` }} />)}</div>}
                      </div>
                    </div>
                  )}
                  <div ref={empChatRef} />
                </div>

                <div style={{ padding: "12px 16px", borderTop: `1px solid ${border}` }}>
                  <div style={{ display: "flex", gap: 8 }}>
                    <button onClick={listening ? () => recognitionRef.current?.stop() : startListening} style={{ width: 36, height: 36, background: listening ? `${empColor}22` : "#13131f", border: `1px solid ${listening ? empColor : border}`, borderRadius: 8, color: listening ? empColor : text2, cursor: "pointer", fontSize: "0.9rem", flexShrink: 0 }}>🎤</button>
                    <textarea value={empInput} onChange={e => setEmpInput(e.target.value)} onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendEmployee(); } }} placeholder={`Ask ${emp.name}...`} rows={1} style={{ flex: 1, background: "#13131f", border: `1px solid ${border}`, borderRadius: 8, padding: "9px 12px", color: text1, fontSize: "0.85rem", outline: "none", resize: "none", fontFamily: "inherit" }} />
                    <button onClick={sendEmployee} disabled={empLoading || !empInput.trim()} style={{ width: 36, height: 36, background: empLoading || !empInput.trim() ? "#13131f" : empColor, border: "none", borderRadius: 8, color: "white", cursor: empLoading || !empInput.trim() ? "not-allowed" : "pointer", fontSize: "1rem", flexShrink: 0 }}>↑</button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TASK BOARD */}
          {view === "tasks" && (
            <div style={{ padding: 16 }}>
              <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
                <input id="newTaskTitle" placeholder="New task title..." style={{ flex: 1, background: surface, border: `1px solid ${border}`, borderRadius: 8, padding: "9px 14px", color: text1, fontSize: "0.85rem", outline: "none" }} />
                <select id="newTaskAssignee" style={{ background: surface, border: `1px solid ${border}`, borderRadius: 8, padding: "9px 10px", color: text2, fontSize: "0.8rem", outline: "none" }}>
                  {Object.values(EMPLOYEES).map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
                </select>
                <button onClick={() => {
                  const title = document.getElementById("newTaskTitle").value;
                  const assignee = document.getElementById("newTaskAssignee").value;
                  if (!title) return;
                  persist(s => ({ ...s, tasks: [...s.tasks, { id: Date.now(), title, assignee, status: "todo", priority: "medium", createdAt: new Date().toISOString() }] }));
                  document.getElementById("newTaskTitle").value = "";
                  notify("Task created!");
                }} style={{ padding: "9px 16px", background: `linear-gradient(135deg, ${accent}, #8b5cf6)`, border: "none", borderRadius: 8, color: "white", fontWeight: 700, fontSize: "0.82rem", cursor: "pointer" }}>+ Add</button>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 12 }}>
                {TASK_STATUSES.map(status => (
                  <div key={status} onDragOver={e => { e.preventDefault(); setDragOver(status); }} onDrop={e => { e.preventDefault(); if (dragging) { moveTask(dragging, status); setDragging(null); setDragOver(null); } }} style={{ background: surface, border: `1px solid ${dragOver === status ? STATUS_COLORS[status] : border}`, borderRadius: 14, padding: 12, minHeight: 200, transition: "border-color 0.15s" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
                      <div style={{ width: 8, height: 8, borderRadius: "50%", background: STATUS_COLORS[status] }} />
                      <span style={{ fontWeight: 700, fontSize: "0.82rem", color: STATUS_COLORS[status] }}>{STATUS_LABELS[status]}</span>
                      <span style={{ background: "#1e293b", color: text2, borderRadius: 12, padding: "1px 7px", fontSize: "0.7rem", marginLeft: "auto" }}>{tasksByStatus[status].length}</span>
                    </div>
                    {tasksByStatus[status].map(task => {
                      const assigneeEmp = EMPLOYEES[task.assignee];
                      return (
                        <div key={task.id} draggable onDragStart={() => setDragging(task.id)} onDragEnd={() => { setDragging(null); setDragOver(null); }}
                          style={{ background: "#13131f", border: `1px solid ${border}`, borderRadius: 10, padding: "10px 12px", marginBottom: 8, cursor: "grab", opacity: dragging === task.id ? 0.5 : 1 }}>
                          <div style={{ fontSize: "0.82rem", fontWeight: 600, color: text1, marginBottom: 8, lineHeight: 1.4 }}>{task.title}</div>
                          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                            {assigneeEmp ? (
                              <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                                <span style={{ fontSize: 12 }}>{assigneeEmp.icon}</span>
                                <span style={{ fontSize: "0.7rem", color: assigneeEmp.color }}>{assigneeEmp.name.split(" ")[0]}</span>
                              </div>
                            ) : <span />}
                            <div style={{ display: "flex", gap: 4 }}>
                              <span style={{ background: task.priority === "high" ? "#ef444422" : task.priority === "low" ? "#10b98122" : "#f59e0b22", color: task.priority === "high" ? "#ef4444" : task.priority === "low" ? "#10b981" : "#f59e0b", padding: "1px 6px", borderRadius: 4, fontSize: "0.65rem", fontWeight: 700 }}>{(task.priority || "med").toUpperCase()}</span>
                              <button onClick={() => deleteTask(task.id)} style={{ background: "none", border: "none", color: "#334155", cursor: "pointer", fontSize: "0.75rem", padding: "0 2px" }}>✕</button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* MEMORY */}
          {view === "memory" && (
            <div style={{ padding: 20 }}>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                <div style={{ background: surface, border: `1px solid ${border}`, borderRadius: 14, padding: 20 }}>
                  <div style={{ fontWeight: 700, marginBottom: 14, color: accent }}>🏢 Company Info</div>
                  {Object.entries(state.company).map(([k, v]) => v && (
                    <div key={k} style={{ marginBottom: 10 }}>
                      <div style={{ fontSize: "0.72rem", color: text2, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 2 }}>{k}</div>
                      <div style={{ fontSize: "0.88rem", color: text1 }}>{v}</div>
                    </div>
                  ))}
                </div>
                <div style={{ background: surface, border: `1px solid ${border}`, borderRadius: 14, padding: 20 }}>
                  <div style={{ fontWeight: 700, marginBottom: 14, color: "#10b981" }}>🧠 CEO Decisions</div>
                  {(state.memory.decisions || []).slice(-8).reverse().map((d, i) => (
                    <div key={i} style={{ marginBottom: 10, padding: "8px 10px", background: "#13131f", borderRadius: 8 }}>
                      <div style={{ fontSize: "0.78rem", color: text2, marginBottom: 2 }}>Q: {d.text}</div>
                      <div style={{ fontSize: "0.72rem", color: "#475569" }}>{d.reply?.slice(0, 80)}...</div>
                    </div>
                  ))}
                  {!(state.memory.decisions || []).length && <div style={{ color: text2, fontSize: "0.82rem" }}>No decisions yet.</div>}
                </div>
              </div>
              <div style={{ marginTop: 16, background: surface, border: `1px solid ${border}`, borderRadius: 14, padding: 20 }}>
                <div style={{ fontWeight: 700, marginBottom: 14 }}>🗑️ Reset Memory</div>
                <button onClick={() => { persist(s => ({ ...s, memory: { decisions: [], projects: [], insights: [] }, ceoChats: [], employeeChats: {}, tasks: [], activities: [] })); notify("Memory cleared"); }} style={{ padding: "8px 16px", background: "#ef444422", border: "1px solid #ef444444", borderRadius: 8, color: "#ef4444", fontSize: "0.82rem", cursor: "pointer" }}>Clear All Memory</button>
              </div>
            </div>
          )}

          {/* SETTINGS */}
          {view === "settings" && (
            <div style={{ padding: 20, maxWidth: 520 }}>
              <div style={{ background: surface, border: `1px solid ${border}`, borderRadius: 14, padding: 24 }}>
                <div style={{ fontWeight: 700, marginBottom: 20 }}>⚙️ Company Settings</div>
                {[["Company Name", "name"], ["Industry", "industry"], ["Main Goal", "goals"], ["Description", "description"]].map(([label, key]) => (
                  <div key={key} style={{ marginBottom: 16 }}>
                    <label style={{ color: text2, fontSize: "0.8rem", display: "block", marginBottom: 6 }}>{label}</label>
                    <input value={state.company[key]} onChange={e => persist(s => ({ ...s, company: { ...s.company, [key]: e.target.value } }))} style={{ width: "100%", background: "#13131f", border: `1px solid ${border}`, borderRadius: 8, padding: "10px 12px", color: text1, fontSize: "0.88rem", outline: "none", boxSizing: "border-box" }} />
                  </div>
                ))}
                <button onClick={() => notify("Settings saved!")} style={{ padding: "10px 20px", background: `linear-gradient(135deg, ${accent}, #8b5cf6)`, border: "none", borderRadius: 8, color: "white", fontWeight: 700, cursor: "pointer" }}>Save Settings</button>
              </div>
              <div style={{ marginTop: 16, background: surface, border: `1px solid ${border}`, borderRadius: 14, padding: 24 }}>
                <div style={{ fontWeight: 700, marginBottom: 12 }}>🔄 Reset Platform</div>
                <button onClick={() => { localStorage.removeItem(STORAGE_KEY); window.location.reload(); }} style={{ padding: "8px 16px", background: "#ef444422", border: "1px solid #ef444444", borderRadius: 8, color: "#ef4444", fontSize: "0.82rem", cursor: "pointer" }}>Reset Everything</button>
              </div>
            </div>
          )}

        </div>
      </div>

      <style>{`
        @keyframes bounce { 0%,60%,100%{transform:translateY(0)} 30%{transform:translateY(-5px)} }
        @keyframes slideIn { from{opacity:0;transform:translateX(20px)} to{opacity:1;transform:translateX(0)} }
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 4px; height: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #1e293b; border-radius: 4px; }
        textarea { min-height: 38px; max-height: 120px; overflow-y: auto; }
        button:active { opacity: 0.8; }
      `}</style>
    </div>
  );
}
