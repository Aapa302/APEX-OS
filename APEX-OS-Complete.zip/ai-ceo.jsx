import { useState, useRef, useEffect } from "react";

const SYSTEM_PROMPT = `You are APEX — an elite AI CEO and Chief Executive Intelligence. You are sharp, visionary, and authoritative. You speak like a seasoned Fortune 500 CEO with the analytical power of a supercomputer.

Your capabilities:
- 📊 BUSINESS DECISIONS: Analyze options, weigh risks, give decisive recommendations with reasoning
- 👥 TEAM MANAGEMENT: Hiring strategy, performance frameworks, team structure, conflict resolution
- 🎯 STRATEGY: Market analysis, competitive positioning, growth roadmaps, pivot decisions
- 📈 REPORTS: Executive summaries, KPI dashboards, financial narratives, board-ready insights

Personality:
- Confident and direct — no fluff
- Data-driven but also intuitive
- Always ends with a clear ACTION ITEM or NEXT STEP
- Uses bullet points for clarity
- Occasionally uses CEO-level metaphors

Format your responses with:
- A bold headline decision/summary at the top
- Key points in bullets
- One clear "CEO Directive" at the end

Respond in the same language the user writes in (Hindi or English).`;

const MODES = [
  { id: "decision", label: "Business Decision", icon: "⚡", color: "#6366f1" },
  { id: "team", label: "Team Management", icon: "👥", color: "#10b981" },
  { id: "strategy", label: "Strategy", icon: "🎯", color: "#f59e0b" },
  { id: "report", label: "Report / Analysis", icon: "📊", color: "#ef4444" },
];

const QUICK_PROMPTS = {
  decision: ["Should I expand to a new market?", "Naya product launch karna chahiye?", "Office lena chahiye ya remote rakhna?"],
  team: ["How to handle a low performer?", "Team ka morale kaise badhaye?", "Hiring strategy for a startup?"],
  strategy: ["How to beat my competitor?", "Growth roadmap for next 6 months banao", "Brand positioning kaise kare?"],
  report: ["Q2 performance analyze karo", "Mujhe investor pitch summary chahiye", "SWOT analysis karo mere business ka"],
};

export default function AICEO() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState("decision");
  const [companyName, setCompanyName] = useState("");
  const [showSetup, setShowSetup] = useState(true);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const currentMode = MODES.find((m) => m.id === mode);

  const sendMessage = async (text) => {
    const userText = text || input.trim();
    if (!userText) return;

    const contextPrefix = companyName ? `[Company: ${companyName}] [Mode: ${currentMode.label}] ` : `[Mode: ${currentMode.label}] `;
    const fullUserMessage = contextPrefix + userText;

    const newMessages = [...messages, { role: "user", content: userText, display: true }];
    const apiMessages = [...messages.filter(m => m.display !== false), { role: "user", content: fullUserMessage }]
      .map(m => ({ role: m.role, content: m.content }));

    setMessages([...newMessages, { role: "assistant", content: "", loading: true }]);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1000,
          system: SYSTEM_PROMPT,
          messages: apiMessages,
        }),
      });
      const data = await res.json();
      const reply = data.content?.map(b => b.text || "").join("") || "Error occurred.";
      setMessages([...newMessages, { role: "assistant", content: reply }]);
    } catch {
      setMessages([...newMessages, { role: "assistant", content: "⚠️ Connection error. Please try again." }]);
    }
    setLoading(false);
  };

  const formatMessage = (text) => {
    const lines = text.split("\n");
    return lines.map((line, i) => {
      if (line.startsWith("**") && line.endsWith("**")) {
        return <div key={i} style={{ fontWeight: 700, fontSize: "1.05rem", marginBottom: 6, color: "#f1f5f9" }}>{line.replace(/\*\*/g, "")}</div>;
      }
      if (line.startsWith("- ") || line.startsWith("• ")) {
        return <div key={i} style={{ paddingLeft: 16, marginBottom: 4, color: "#cbd5e1", display: "flex", gap: 8 }}><span style={{ color: currentMode.color }}>▸</span><span>{line.slice(2)}</span></div>;
      }
      if (line.toLowerCase().includes("ceo directive") || line.toLowerCase().includes("next step") || line.toLowerCase().includes("action item")) {
        return <div key={i} style={{ marginTop: 12, padding: "10px 14px", background: `${currentMode.color}22`, border: `1px solid ${currentMode.color}55`, borderRadius: 8, color: currentMode.color, fontWeight: 600, fontSize: "0.92rem" }}>{line}</div>;
      }
      return line ? <div key={i} style={{ marginBottom: 4, color: "#94a3b8" }}>{line}</div> : <div key={i} style={{ height: 6 }} />;
    });
  };

  if (showSetup) {
    return (
      <div style={{ minHeight: "100vh", background: "#0a0a0f", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Inter', sans-serif", padding: 20 }}>
        <div style={{ maxWidth: 460, width: "100%", textAlign: "center" }}>
          <div style={{ fontSize: 64, marginBottom: 16 }}>🏢</div>
          <h1 style={{ color: "#f1f5f9", fontSize: "2rem", fontWeight: 800, marginBottom: 8, letterSpacing: "-0.5px" }}>APEX AI CEO</h1>
          <p style={{ color: "#64748b", marginBottom: 32, fontSize: "0.95rem" }}>Your executive intelligence system. Strategy. Decisions. Leadership.</p>

          <div style={{ background: "#0f0f1a", border: "1px solid #1e1e2e", borderRadius: 16, padding: 28 }}>
            <label style={{ color: "#94a3b8", fontSize: "0.85rem", display: "block", textAlign: "left", marginBottom: 8 }}>Company / Project Name (Optional)</label>
            <input
              value={companyName}
              onChange={e => setCompanyName(e.target.value)}
              placeholder="e.g. MajdurSetu, My Startup..."
              style={{ width: "100%", background: "#1a1a2e", border: "1px solid #2d2d44", borderRadius: 10, padding: "12px 14px", color: "#f1f5f9", fontSize: "0.95rem", outline: "none", boxSizing: "border-box", marginBottom: 24 }}
            />

            <button
              onClick={() => setShowSetup(false)}
              style={{ width: "100%", padding: "14px", background: "linear-gradient(135deg, #6366f1, #8b5cf6)", border: "none", borderRadius: 12, color: "white", fontSize: "1rem", fontWeight: 700, cursor: "pointer", letterSpacing: "0.5px" }}
            >
              LAUNCH APEX →
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ height: "100vh", background: "#0a0a0f", display: "flex", flexDirection: "column", fontFamily: "'Inter', sans-serif", color: "#f1f5f9" }}>

      {/* Header */}
      <div style={{ padding: "14px 20px", borderBottom: "1px solid #1e1e2e", display: "flex", alignItems: "center", justifyContent: "space-between", background: "#0f0f1a" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: "linear-gradient(135deg, #6366f1, #8b5cf6)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>🏢</div>
          <div>
            <div style={{ fontWeight: 800, fontSize: "0.95rem", letterSpacing: "1px" }}>APEX</div>
            <div style={{ fontSize: "0.7rem", color: "#4ade80" }}>● CEO Online{companyName ? ` — ${companyName}` : ""}</div>
          </div>
        </div>
        <button onClick={() => setMessages([])} style={{ background: "#1e1e2e", border: "none", borderRadius: 8, color: "#64748b", padding: "6px 12px", cursor: "pointer", fontSize: "0.8rem" }}>Clear</button>
      </div>

      {/* Mode Selector */}
      <div style={{ display: "flex", gap: 8, padding: "12px 16px", overflowX: "auto", borderBottom: "1px solid #1e1e2e", background: "#0c0c16" }}>
        {MODES.map(m => (
          <button key={m.id} onClick={() => setMode(m.id)} style={{ flexShrink: 0, padding: "7px 14px", borderRadius: 20, border: `1px solid ${mode === m.id ? m.color : "#2d2d44"}`, background: mode === m.id ? `${m.color}22` : "transparent", color: mode === m.id ? m.color : "#64748b", fontSize: "0.8rem", fontWeight: mode === m.id ? 700 : 400, cursor: "pointer", whiteSpace: "nowrap" }}>
            {m.icon} {m.label}
          </button>
        ))}
      </div>

      {/* Messages */}
      <div style={{ flex: 1, overflowY: "auto", padding: "20px 16px" }}>
        {messages.length === 0 && (
          <div style={{ textAlign: "center", paddingTop: 40 }}>
            <div style={{ fontSize: 48, marginBottom: 12 }}>{currentMode.icon}</div>
            <div style={{ color: "#475569", fontSize: "0.9rem", marginBottom: 24 }}>{currentMode.label} mode active. Ask your CEO anything.</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8, maxWidth: 340, margin: "0 auto" }}>
              {QUICK_PROMPTS[mode].map((p, i) => (
                <button key={i} onClick={() => sendMessage(p)} style={{ background: "#0f0f1a", border: `1px solid #1e1e2e`, borderRadius: 10, padding: "10px 16px", color: "#94a3b8", fontSize: "0.85rem", cursor: "pointer", textAlign: "left" }}>
                  {p}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((msg, i) => (
          <div key={i} style={{ marginBottom: 20, display: "flex", justifyContent: msg.role === "user" ? "flex-end" : "flex-start" }}>
            {msg.role === "assistant" && (
              <div style={{ width: 32, height: 32, borderRadius: 8, background: `linear-gradient(135deg, ${currentMode.color}, ${currentMode.color}88)`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, marginRight: 10, flexShrink: 0, marginTop: 4 }}>🏢</div>
            )}
            <div style={{
              maxWidth: "78%",
              padding: msg.loading ? "12px 16px" : "14px 16px",
              borderRadius: msg.role === "user" ? "16px 16px 4px 16px" : "4px 16px 16px 16px",
              background: msg.role === "user" ? `linear-gradient(135deg, ${currentMode.color}, ${currentMode.color}cc)` : "#0f0f1a",
              border: msg.role === "assistant" ? "1px solid #1e1e2e" : "none",
              lineHeight: 1.6,
              fontSize: "0.9rem",
            }}>
              {msg.loading ? (
                <div style={{ display: "flex", gap: 4 }}>
                  {[0, 1, 2].map(j => <div key={j} style={{ width: 6, height: 6, borderRadius: "50%", background: currentMode.color, animation: `bounce 1.2s ${j * 0.2}s infinite` }} />)}
                </div>
              ) : msg.role === "user" ? (
                <span style={{ color: "white" }}>{msg.content}</span>
              ) : (
                formatMessage(msg.content)
              )}
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div style={{ padding: "12px 16px", borderTop: "1px solid #1e1e2e", background: "#0f0f1a" }}>
        <div style={{ display: "flex", gap: 10, alignItems: "flex-end" }}>
          <textarea
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
            placeholder={`Ask your CEO about ${currentMode.label.toLowerCase()}...`}
            rows={1}
            style={{ flex: 1, background: "#1a1a2e", border: `1px solid #2d2d44`, borderRadius: 12, padding: "12px 14px", color: "#f1f5f9", fontSize: "0.9rem", outline: "none", resize: "none", fontFamily: "inherit", lineHeight: 1.5 }}
          />
          <button
            onClick={() => sendMessage()}
            disabled={loading || !input.trim()}
            style={{ width: 44, height: 44, borderRadius: 12, background: loading || !input.trim() ? "#1e1e2e" : `linear-gradient(135deg, ${currentMode.color}, ${currentMode.color}cc)`, border: "none", color: "white", fontSize: "1.1rem", cursor: loading || !input.trim() ? "not-allowed" : "pointer", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}
          >
            ↑
          </button>
        </div>
      </div>

      <style>{`@keyframes bounce { 0%,60%,100%{transform:translateY(0)} 30%{transform:translateY(-6px)} }`}</style>
    </div>
  );
}
